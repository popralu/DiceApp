package com.example.diceapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.resources.Compatibility.Api21Impl.inflate

class MainActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId", "ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn_roll: Button = findViewById(R.id.btn_roll)
        val diceImgA : ImageView = findViewById(R.id.diceA)
        val diceImgB : ImageView = findViewById(R.id.diceB)

        btn_roll.setOnClickListener {
            val randomDice1 : Int = (1..6).random()
            val randomDice2 : Int = (1..6).random()

            val imageA = when (randomDice1) {
                1 -> R.drawable.dice_1
                2 -> R.drawable.dice_2
                3 -> R.drawable.dice_3
                4 -> R.drawable.dice_4
                5 -> R.drawable.dice_5
                else -> R.drawable.dice_6
            }

            val imageB = when (randomDice2) {
                1 -> R.drawable.dice_1
                2 -> R.drawable.dice_2
                3 -> R.drawable.dice_3
                4 -> R.drawable.dice_4
                5 -> R.drawable.dice_5
                else -> R.drawable.dice_6
            }
             diceImgA.setImageResource(imageA)
             diceImgB.setImageResource(imageB)

        }
    }
}







